import Data.Char
import Data.List
main::IO()
main = do
    print $ reduceStr "dabAcCaCBAcCcaDD"
    print $ reduceStr "dabAcCaCBAcCcaDD" == "dabCBAcaDD" -- dabAcCaCBAcCcaDD -> dabAaCBAcCcaDD -> dabCBAcCcaDD -> dabCBAcaDD

isDuplicate :: Char -> Char -> Bool
isDuplicate l r = l /= r && (toLower l == toLower r) && (toLower l ==r || toLower r == l )

reduceStr :: String -> String
reduceStr [] = []
reduceStr (x1:x2:str) = if isDuplicate x1 x2 then reduceStr str else x1:x2:reduceStr str 
--trqbva da se puska otnovo i otnovo dokato mine prez celiqt string bez nito edin put da e izpulneno isDuplicate, ili ako nameri Duplciates str da stava ostanaliat string otlqvo i str (bez x1 x2), no loshoto e che nqmam ideq kak moje da stane (probvah i s foldr no isDuplicate ne e operacia a predicate)
